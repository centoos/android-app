package com.naughty.centos.fiberbaselogin;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

/**
 * Created by mahismati on 25/7/17.
 */

public class Choose extends AppCompatActivity {
    Button b1,b2;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose);
        b1= (Button) findViewById(R.id.clickupload);
        b2= (Button) findViewById(R.id.viewnotice);


    }
    public void view_notice(View view)
    {
        Intent intent=new Intent(getApplicationContext(),IMAGELIST.class);
        startActivity(intent);
    }
    public void upload(View view)
    {
        Intent intent=new Intent(getApplicationContext(),HI.class);
        startActivity(intent);
    }
}
