package com.naughty.centos.fiberbaselogin;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by mahismati on 24/7/17.
 */

public class ImageUPLOAD extends AppCompatActivity {
    public String name;
    public String uri;

    public ImageUPLOAD(String name, String uri) {
        this.name = name;
        this.uri = uri;
    }

    public String getName() {
        return name;
    }

    public String getUri() {
        return uri;
    }

    public ImageUPLOAD() {
    }
}
