package com.naughty.centos.fiberbaselogin;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class IMAGELIST extends AppCompatActivity {
    private DatabaseReference mDatabaseref;
    private List<ImageUPLOAD> imglist;
    private ListView LV;
    private Imagelistadapter imagelistadapter;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_imagelist);
        imglist=new ArrayList<>();
        LV= (ListView) findViewById(R.id.LISTVIEW);
        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("PLEASE WAIT...");
        progressDialog.show();
        mDatabaseref= FirebaseDatabase.getInstance().getReference(HI.FB_DATABASE_PATH);
        mDatabaseref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                progressDialog.dismiss();
                for(DataSnapshot snapshot :dataSnapshot.getChildren()){

                    ImageUPLOAD imageUPLOAD=snapshot.getValue(ImageUPLOAD.class);
                    imglist.add(imageUPLOAD);

                }
                imagelistadapter=new Imagelistadapter(IMAGELIST.this,R.layout.imagelist,imglist);
                LV.setAdapter(imagelistadapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                progressDialog.dismiss();

            }
        });
    }
}
