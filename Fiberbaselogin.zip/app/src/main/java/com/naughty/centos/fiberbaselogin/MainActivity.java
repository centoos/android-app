package com.naughty.centos.fiberbaselogin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
Button loginn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //registor= (Button) findViewById(R.id.button);
        loginn= (Button) findViewById(R.id.button2);
    }

    public void loginbtn(View view)
    {
        Intent intent=new Intent(getApplicationContext(),Loginactivity.class);
        startActivity(intent);
    }
}
